$(window).scroll(function () {
    var scrollPosition = $(this).scrollTop();
        if (scrollPosition >140 ) {
            $('header').css('background-color','rgba(10,15,22,1)');
            $('.top_search').css('border','1px solid #395278');
            $('.top_search input').css('background-color','#0a0f16');
        } else {
            $('header').css('background-color','rgba(10,15,22,0.2)');
            $('.top_search').css('border','1px solid #4b4b45');
            $('.top_search input').css('background-color','#101a25');
        }
});
$(document).ready(function(){
    //모바일 네비게이션
    $(".nav1_open").click(function() {
         $(".category").addClass("on");
         $(".member").removeClass("on");
    });
    $(".nav1_close").click(function() {
        $(".category").removeClass("on");
    });

    $(".nav2_open").click(function() {
         $(".member").addClass("on");
         $(".category").removeClass("on");
    });
    $(".nav2_close").click(function() {
        $(".member").removeClass("on");
    });


    //디테일 페이지 qna 내용 열고 닫기
    $(".question_tit a").click(function(){
        var qnaContent =$(this).parents().children(".qna_conts_wrap");
        $(".qna_conts_wrap").removeClass("on");
        qnaContent.addClass("on");
        //qnaContent.removeClass("on");
     });
    $(".qna_list_close").click(function(){ 
        var qnaContent2=$(this).parents().children(".qna_conts_wrap");
        qnaContent2.removeClass("on");
    });
    //디테일 페이지 qna 글쓰기 모달창 
    $(".ask_btn").click(function(){
        $(".dim").fadeIn();
        $("#qna_write_modal").fadeIn();
    });
    $("#qna_write_cancel").click(function(){
        $(".dim").fadeOut();
        $("#qna_write_modal").fadeOut();
    });
    $(".qna_write_btn").click(function(){
        $(".dim").fadeIn();
        $("#qna_answer_modal").fadeIn();

    });
    $("#qna_answer_cancel").click(function(){
        $(".dim").fadeOut();
        $("#qna_answer_modal").fadeOut();

    });
    //디테일 페이지 이용후기 내용 열고 닫기
    $("#review dt").click(function(){
        var detailBoardContent =$(this).parents().children(".detail_review_wrap");
        $(".detail_review_wrap").removeClass("on");
        detailBoardContent.addClass("on");
        
        
    });
    $(".review_list_close").click(function(){
        var detailBoardContent =$(this).parents().children(".detail_review_wrap");
        detailBoardContent.removeClass("on");
    });

       //디테일 페이지 이용후기 글쓰기 모달 제어
    $("#review_write").click(function(){
        $(".dim").fadeIn();
        $("#revew_write_modal").fadeIn();
    });
    $("#review_write_cancel").click(function(){
        $(".dim").fadeOut();
        $("#revew_write_modal").fadeOut();
    });
     //디테일 페이지 공지사항 내용 열고 닫기
     $("#notice dt").click(function(){
        var detailBoardContent =$(this).parents().children(".detail_notice_wrap");
        $(".detail_notice_wrap").removeClass("on");
        detailBoardContent.addClass("on");
     });
    $(".notice_list_close").click(function(){
        var detailBoardContent =$(this).parents().children(".detail_notice_wrap");
        detailBoardContent.removeClass("on");
    });
    //디테일 페이지 공지사항 글쓰기 모달 제어
    $("#notice_write").click(function(){
        $(".dim").fadeIn();
        $("#notice_write_modal").fadeIn();
    });
      $("#notice_write_cancel").click(function(){
        $(".dim").fadeOut();
        $("#notice_write_modal").fadeOut();
    });
    
    //디테일 페이지02 강의리스트 내용 열고 닫기
    $(".lecture_conts li:first-child .lecture_list").addClass("on");
    $(".lecture_conts li").click(function(){
        var lectureListContent =$(this).children(".lecture_list");
        var lectureListHeight =$(this).children(".lecture_list").height();
        if(lectureListHeight == 0){
            $(".lecture_list").removeClass("on");
            lectureListContent.addClass("on");
        }
    });  

});

/*상세페이지 탭소스*/
$(function () {	
	tab('#tab',0);	
});
$(function () {	
	tab('#tab02',0);	
});
function tab(e, num){
    var num = num || 0;
    var menu = $(e).children();
    var con = $(e+'_con').children();
    var select = $(menu).eq(num);
    var i = num;

    select.addClass('on');
    con.eq(num).show();

    menu.click(function(){
        if(select!==null){
            select.removeClass("on");
            con.eq(i).hide();
        }

        select = $(this);	
        i = $(this).index();

        select.addClass('on');
        con.eq(i).show();
    });
}