package com.codingclass.service;

import java.util.List;

import com.codingclass.domain.ClassUserListCriteria;
import com.codingclass.domain.ClsuserListVO;

public interface ClsuserListService {

	/*
	 *작성자 : 정찬화
	 *메소드명 : getListpaging
	 *기능 : 클래스 학습자 클래스별 리스트 뽑아냄
	 */
	public List<ClsuserListVO> getListWithPaging(ClassUserListCriteria cri,Long userNo);
	
	/*
	 *작성자 : 정찬화
	 *메소드명 : getListWithPagingPerClass
	 *기능 : 클래스 별 학습자 전체 뽑아냄 
	 */
	public List<ClsuserListVO> getListWithPagingPerClass(ClassUserListCriteria cri,Long classNo);
	
	/*
	 *작성자 : 정찬화
	 *메소드명 : searchCnt
	 *기능 : 사용자 id 검색
	 */
	public int searchCnt(ClassUserListCriteria cri,Long userNo);
	
	public int searchCntPerClass(ClassUserListCriteria cri,Long classNo);
}
