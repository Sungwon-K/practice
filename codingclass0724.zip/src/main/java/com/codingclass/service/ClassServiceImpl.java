package com.codingclass.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.codingclass.domain.ClassListDTO;
import com.codingclass.domain.ClassVO;
import com.codingclass.domain.Criteria;
import com.codingclass.domain.ReviewListDTO;
import com.codingclass.mapper.ClassMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class ClassServiceImpl implements ClassService{

	private ClassMapper mapper;

	/*
	작성자 : 고은진
	메소드명 : getClassQnaList()
	기능 : classqna테이블 + classes테이블 
	*/
	@Override
	public List<ClassListDTO> getClassQnaList() {
		
		return mapper.getClassQnaList();
	}

	/*
	작성자 : 고은진
	메소드명 : getClassList()
	기능 : review테이블 + classes테이블 + users테이블
	*/
	@Override
	public List<ReviewListDTO> getClassList() {
		
		return mapper.getClassReviewList();
	}

	/*
	작성자 : 고은진
	메소드명 : getClassQnaList()
	기능 : 클래스테이블에 있는 모든 컬럼을 가져올 수 있음.
	*/
	@Override
	public List<ClassVO> getList(Criteria cri) {
		
		return mapper.getListWithPaging(cri);
	}

	@Override
	public int getTotalCount(Criteria cri) {
		
		return mapper.getTotalCount(cri);
	}
	
	
}
