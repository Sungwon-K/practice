package com.codingclass.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.codingclass.domain.ClassUserListCriteria;
import com.codingclass.domain.ClsuserListVO;
import com.codingclass.mapper.ClsuserListMapper;

import lombok.AllArgsConstructor;


@Service
@AllArgsConstructor
public class ClsuserListServiceImpl implements ClsuserListService{

	private ClsuserListMapper mapper;
	


	/*
	 *작성자 : 정찬화
	 *메소드명 : getListpaging
	 *기능 : 클래스 학습자 클래스별 리스트 뽑아냄
	 */

	@Override
	public List<ClsuserListVO> getListWithPaging(ClassUserListCriteria cri, Long userNo) {
		// TODO Auto-generated method stub
		return mapper.getListWithPaging(cri,userNo);
	}
	/*
	 *작성자 : 정찬화
	 *메소드명 : getListpaging
	 *기능 : 클래스 학습자 클래스별 리스트 뽑아냄
	 */
	@Override
	public List<ClsuserListVO> getListWithPagingPerClass(ClassUserListCriteria cri, Long classNo) {
		// TODO Auto-generated method stub
		return mapper.getListWithPagingPerClass(cri,classNo);
	}

	/*
	 *작성자 : 정찬화
	 *메소드명 : searchCnt
	 *기능 : 전체 사용자 카운트 ( 키워드에 작성시 해당 사용자만 나옴)
	 */
	@Override
	public int searchCnt(ClassUserListCriteria cri,Long userNo) {
		// TODO Auto-generated method stub
		return mapper.searchCnt(cri,userNo);
	}
	
	/*
	 *작성자 : 정찬화
	 *메소드명 : searchCntPerClass
	 *기능 : 클래스별 전체 사용자 카운트 ( 키워드에 작성시 해당 사용자만 나옴)
	 */
	@Override
	public int searchCntPerClass(ClassUserListCriteria cri,Long classNo) {
		// TODO Auto-generated method stub
		return mapper.searchCntPerClass(cri,classNo);
	}

	
}
