package com.codingclass.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingclass.domain.ClassVO;
import com.codingclass.domain.Criteria;
import com.codingclass.domain.SessionVO;
import com.codingclass.domain.StudyVideoVO;
import com.codingclass.mapper.ClassMapper;
import com.codingclass.mapper.SessionMapper;
import com.codingclass.mapper.StudyVideoMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class StudyManagerServiceImpl implements StudyManagerService{

	@Setter(onMethod_= @Autowired)
	private ClassMapper classMapper;
	
	@Setter(onMethod_= @Autowired)
	private SessionMapper sessionMapper;
	
	@Setter(onMethod_= @Autowired)
	private StudyVideoMapper studyVideoMapper;
	
	
	/*
	 *작성자 : 김성원
	 *메소드명 : register
	 *기능 : 
	 *1.특정 클래스 정보 입력
	 *2.해당 클래스에 포함된 session들의 정보 입력
	 *3.각 session들에 포함된 studyVideo 정보 입력
	 */
	@Override
	public void register(ClassVO classes) {
		log.info("regisert :" + classes);
		classMapper.classInsert(classes);	
		
		if(classes.getSessionList() == null || classes.getSessionList().size() <= 0) {
			return;
		}
		
		classes.getSessionList().forEach(session ->{
			session.setClassNo(classes.getClassNo());		
			sessionMapper.sessionInsert(session);
			
			if(session.getStudyVideoList() == null || session.getStudyVideoList().size() <= 0) {
				return;
			}
			
			session.getStudyVideoList().forEach(studyVideo ->{
				studyVideo.setSessionNo(session.getSessionNo());		
				studyVideoMapper.studyVideoInsert(studyVideo);
			});
			
		});		
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : get
	 *기능 : 클래스 정보 한건 검색
	 */
	@Override
	public ClassVO get(Long classNo) {
		
		log.info("get......." + classNo);
		
		return classMapper.studyClassRead(classNo);
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : modify
	 *기능 : 클래스 정보 수정
	 */
	@Override
	public void modify(ClassVO classes) {
		log.info("modify :" + classes);		
		classMapper.classUpdate(classes);	
		
		if(classes.getSessionList() == null || classes.getSessionList().size() <= 0) {
			return;
		}
		
		classes.getSessionList().forEach(session ->{
			session.setClassNo(classes.getClassNo());		
			sessionMapper.sessionUpdate(session);
			
			if(session.getStudyVideoList() == null || session.getStudyVideoList().size() <= 0) {
				return;
			}
			
			session.getStudyVideoList().forEach(studyVideo ->{
				studyVideo.setSessionNo(session.getSessionNo());		
				studyVideoMapper.studyVideoUpdate(studyVideo);
			});
			
		});
		
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : removeCall
	 *기능 : 클래스 정보 삭제 요청
	 */
	@Override
	public boolean removeCall(Long classNo) {
		
		return classMapper.deleteCall(classNo)==1;
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : removeCallCancel
	 *기능 : 클래스 정보 삭제 요청
	 */
	@Override
	public boolean removeCallCancel(Long classNo) {
		// TODO Auto-generated method stub
		return classMapper.deleteCallCancel(classNo)==1;
	}
	
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getList
	 *기능 : 클래스 리스트 검색
	 */
	@Override
	public List<ClassVO> getList(Criteria cri, Long userNo) {
		
		return classMapper.getClassListWithPaging(cri, userNo);
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getSessionList
	 *기능 : 세션 리스트 검색
	 */
	@Override
	public List<SessionVO> getSessionList(Long classNo) {
		log.info("get Session list by claaNo" + classNo);
		
		return sessionMapper.findByClassNo(classNo);
	}

	/*
	 *작성자 : 김성원
	 *메소드명 : getStudyVideoList
	 *기능 : 강의 리스트 검색
	 */
	@Override
	public List<StudyVideoVO> getStudyVideoList(Long sessionNo) {
		log.info("get StudyVideo list by sessionNo : " + sessionNo);
		
		return studyVideoMapper.findBySessionNo(sessionNo);
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getTotal
	 *기능 : 페이징 토탈 페이지 검색
	 */
	@Override
	public int getTotal(Criteria cri) {
		log.info("get total count");
		return classMapper.getClassTotalCount(cri);
	}

	/*
	 *작성자 : 김성원
	 *메소드명 : studyVideoDelete
	 *기능 : 지정된 강의 번호 정보 삭제
	 */
	@Override
	public void studyVideoDelete(Long studyVideoNo) {
		log.info("해당 studyVideo 내용 삭제 : "+studyVideoNo );
		studyVideoMapper.delete(studyVideoNo);		
	}

	
}
