package com.codingclass.service;

import java.util.List;

import com.codingclass.domain.ClassListDTO;
import com.codingclass.domain.ClassVO;
import com.codingclass.domain.Criteria;
import com.codingclass.domain.ReviewListDTO;

public interface ClassService {
	
	/* classList목록  */
	public List<ClassVO> getList(Criteria cri);
	
	/* class qna 목록  */
	public List<ClassListDTO> getClassQnaList();
	
	/* class 수강평 목록  */
	public List<ReviewListDTO> getClassList();
	
	/* classlist.jsp 전체 목록 수 */
	public int getTotalCount(Criteria cri);
}
