package com.codingclass.service;

import java.util.List;

import com.codingclass.domain.ClassVO;
import com.codingclass.domain.Criteria;
import com.codingclass.domain.SessionVO;
import com.codingclass.domain.StudyVideoVO;

public interface StudyManagerService {
	
	/*
	 *작성자 : 김성원
	 *메소드명 : register
	 *기능 : 클래스 정보 입력
	 */
	public void register(ClassVO classes);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : get
	 *기능 : 클래스 정보 한건 검색
	 */
	public ClassVO get(Long classNo);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : modify
	 *기능 : 클래스 정보 수정
	 */
	public void modify(ClassVO classes);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : removeCall
	 *기능 : 클래스 정보 삭제 요청
	 */
	public boolean removeCall(Long classNo);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : removeCallCancel
	 *기능 : 클래스 정보 삭제 요청취소
	 */
	public boolean removeCallCancel(Long classNo);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getList
	 *기능 : 클래스 리스트 검색
	 */
	public List<ClassVO> getList(Criteria cri, Long userNo);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getSessionList
	 *기능 : 세션 리스트 검색
	 */
	public List<SessionVO> getSessionList(Long classNo);

	/*
	 *작성자 : 김성원
	 *메소드명 : getStudyVideoList
	 *기능 : 강의 리스트 검색
	 */
	public List<StudyVideoVO> getStudyVideoList(Long sessionNo);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getTotal
	 *기능 : 페이징 토탈 페이지 검색
	 */	
	public int getTotal(Criteria cri);
		
	/*
	 *작성자 : 김성원
	 *메소드명 : studyVideoDelete
	 *기능 : 지정된 강의 번호 정보 삭제
	 */	
	public void studyVideoDelete(Long studyVideoNo);
}
