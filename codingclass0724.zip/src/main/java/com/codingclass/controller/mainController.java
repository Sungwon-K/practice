package com.codingclass.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.codingclass.domain.Criteria;
import com.codingclass.service.ClassService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/*")
@AllArgsConstructor
public class mainController {
	
	private ClassService classService;
	
	/*
	작성자 : 고은진
	기능 : index페이지에 클래스목록과 클래스qna목록, 클래스수강평목록을 전달, 검색처리
	*/
	@GetMapping("/index")
	public void indexList(Criteria cri, Model model) {
		
		model.addAttribute("list", classService.getList(cri));
		
		model.addAttribute("qnalist", classService.getClassQnaList());
		model.addAttribute("reviewlist", classService.getClassList());
		
	}
	
}
