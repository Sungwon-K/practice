package com.codingclass.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.codingclass.domain.ClassVO;
import com.codingclass.domain.Criteria;
import com.codingclass.domain.PageDTO;
import com.codingclass.domain.SessionVO;
import com.codingclass.domain.StudyVideoVO;
import com.codingclass.service.StudyManagerService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/studyManager/*")
@AllArgsConstructor
public class StudyManagerController {

	private StudyManagerService service;
	
	/*
	 *작성자 : 김성원
	 *메소드명 : classList
	 *기능 : studyManagerService의 getList로 불러온 정보를 list에 담고 classList페이지 이동 
	 */
	@GetMapping("/classList")
	public void classList(@RequestParam("userNo") Long userNo, Criteria cri, Model model) {
		log.info("classList");
		model.addAttribute("list",service.getList(cri,userNo));
		model.addAttribute("pageMaker",new PageDTO(cri, service.getTotal(cri)));
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : classManage(get)
	 *기능 :
	 *1.request받은 classNo를 studyManagerService의 get메소드에게 전달한다.
	 *2.get메소드로 불러온 정보를 class에 담고 classManage페이지 이동 
	 */
	@GetMapping("/classManage")
	public void classManage(@RequestParam("classNo") Long classNo,@ModelAttribute("cri") Criteria cri, Model model) {
		
		log.info("/classManage");
		model.addAttribute("classes",service.get(classNo));		
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : classModify
	 *기능 :
	 *1.studyManagerService의 modify메소드에게 classes정보를 전달한다.
	 *2.수정사항이 있으면 result에 success를 포장한다.('#번 수정 완료했습니다.'처리를 위해)
	 *3.모든 처리 후 classList로 이동한다. 
	 */	
	@PostMapping("/classModify")
	public String classManage(ClassVO classes, RedirectAttributes rttr) {
		
		log.info("================================");
		log.info("modify :" + classes);
		
		if(classes.getSessionList() != null) {
			classes.getSessionList().forEach(sessions -> {
				
				log.info(sessions);
			
				if(sessions.getStudyVideoList() != null) {
					sessions.getStudyVideoList().forEach(studyVideo -> log.info(studyVideo));
				}			
			});
		}
		log.info("================================");				
		service.modify(classes);		
		rttr.addFlashAttribute("result", "success");
		return "redirect:/studyManager/classList?userNo="+classes.getUserNo();
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : classRegisert(get)
	 *기능 : classRegister로 이동 
	 */
	@GetMapping("/classRegister")
	public void classRegister(@RequestParam("userNo") Long userNo,@ModelAttribute("cri") Criteria cri,Model model) {
		model.addAttribute("userNo",userNo);
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : classRegisert(post)
	 *기능 : 
	 *1.studyManagerService의 register메소드에게 classes정보를 전달한다.
	 *2.해당 클래스의 classNo를 result로 포장한다.('#번 입력 완료했습니다.'처리를 위해)
	 *3.모든 처리 후 classList로 이동한다. 
	 */
	@PostMapping("/classRegister")
	public String classRegister(ClassVO classes, RedirectAttributes rttr) {		
		log.info("================================");
		log.info("register: " + classes);	
		
		if(classes.getSessionList() != null) {
			classes.getSessionList().forEach(sessions -> {
				
				log.info(sessions);
			
				if(sessions.getStudyVideoList() != null) {
					sessions.getStudyVideoList().forEach(studyVideo -> log.info(studyVideo));
				}			
			});
		}
		
		log.info("================================");
		service.register(classes);		
		rttr.addFlashAttribute("result", classes.getClassNo());		
		return "redirect:/studyManager/classList?userNo="+classes.getUserNo();
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : classRemove
	 *기능 :
	 *1.studyManagerService의 removeCall메소드에게 classNo정보를 전달한다.
	 *2.수정사항이 있으면 result에 success를 포장한다.('#번 삭제 완료했습니다.'처리를 위해)
	 *3.모든 처리 후 classList로 이동한다. 
	 */
	@PostMapping("/classRemove")
	public String classRemove(ClassVO vo, RedirectAttributes rttr) {
		log.info("removeCall :" + vo.getClassNo());
		
		if(service.removeCall(vo.getClassNo())) {
			rttr.addFlashAttribute("result","success");
		}
		return "redirect:/studyManager/classList?userNo="+vo.getUserNo();
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : classRemoveCancel
	 *기능 :
	 *1.studyManagerService의 removeCallCancel메소드에게 classNo정보를 전달한다.
	 *2.수정사항이 있으면 result에 success를 포장한다.('#번 삭제 완료했습니다.'처리를 위해)
	 *3.모든 처리 후 classList로 이동한다. 
	 */
	@PostMapping("/classRemoveCancel")
	public String classRemoveCancel(ClassVO vo, RedirectAttributes rttr) {
		log.info("removeCallCancel :" + vo.getClassNo());
		
		if(service.removeCallCancel(vo.getClassNo())) {
			rttr.addFlashAttribute("result","success");
		}
		return "redirect:/studyManager/classList?userNo="+vo.getUserNo();
	}	
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getSessionList
	 *기능 : classNo에 따른 세션리스트 정보를 불러온다.
	 */
	@GetMapping(value = "/getSessionList",
				produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
		
	public ResponseEntity<List<SessionVO>> getSessionList(Long classNo){
		log.info("getSessionList" + classNo);
			
		return new ResponseEntity<>(service.getSessionList(classNo),HttpStatus.OK);
	}
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getStudyVideoList
	 *기능 : sessionNo에 따른 강의리스트 정보를 불러온다.
	 */
	@GetMapping(value = "/getStudyVideoList",
				produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
		
	public ResponseEntity<List<StudyVideoVO>> getStudyVideoList(Long sessionNo){
		log.info("getStudyVideoList" + sessionNo);
			
		return new ResponseEntity<>(service.getStudyVideoList(sessionNo),HttpStatus.OK);
	}
}
