package com.codingclass.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.codingclass.domain.ClassUserListCriteria;
import com.codingclass.domain.ClsuserPageDTO;
import com.codingclass.service.ClsuserListService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/clss/*")
@AllArgsConstructor
public class ClsuserListController {
	//** Criteria 이름은 파라미터 갯수가 달라 ClassUserListCriteria으로 변경 합니다
	
	private ClsuserListService service;
	
	
	
	/*
	 *작성자 : 정찬화
	 *메소드명 : getListWithPaging
	 *기능 : 해당 강사 강의 학습자 총인원 (*검색 합침)
	 */
	@GetMapping("/clses")
	public void getListWithPaging(@RequestParam("userNo") Long userNo, ClassUserListCriteria cri, Model model) {
		
		cri.setUserno(userNo);
		model.addAttribute("clsuser",service.getListWithPaging(cri,userNo));
		model.addAttribute("userNo",userNo);
		
		int total = service.searchCnt(cri,userNo);
		model.addAttribute("pageMaker",new ClsuserPageDTO(cri,total));
		System.out.println("전체 목록 수 : "+total);
	}
	/*
	 *작성자 : 정찬화
	 *메소드명 : getListWithPagingPerClass
	 *기능 : 해당 강사 강의 클래스별 학습자 총인원(*검색 합침)
	 */
	
	@GetMapping("/clsesbyno")
	public void getListWithPagingPerClass( @RequestParam("classNo") Long classNo, ClassUserListCriteria cri, Model model) {
		model.addAttribute("clsuser",service.getListWithPagingPerClass(cri,classNo));
		model.addAttribute("classNo",classNo);
		
		cri.setClassno(classNo);
		
		int total = service.searchCntPerClass(cri,classNo);
		model.addAttribute("pageMaker",new ClsuserPageDTO(cri,total));
		System.out.println("전체 목록 수 : "+total);
	}

}

