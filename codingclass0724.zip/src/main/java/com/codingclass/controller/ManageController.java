package com.codingclass.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.codingclass.service.StudyManagerService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@AllArgsConstructor
public class ManageController {
	
	private StudyManagerService service;
	
	@PostMapping("/deleteStudyVideo")
	@ResponseBody
	public String deleteStudyVideo(@RequestParam("studyVideoNo") Long studyVideoNo){
		
		log.info("delete studyVideoNo : " + studyVideoNo);			
		
		try {
			service.studyVideoDelete(studyVideoNo);
		}catch(Exception e) {
			e.printStackTrace();
		}		
		return studyVideoNo+"삭제되었습니다.";
	}
}
