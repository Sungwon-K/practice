package com.codingclass.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.codingclass.domain.Criteria;
import com.codingclass.domain.PageDTO;
import com.codingclass.service.ClassService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/class/*")
@AllArgsConstructor
public class ClassController {
	
	private ClassService service;
	
	/*
	 * 작성자 : 고은진
	 * 기능 :  클래스리스트화면에서 리스트 출력 / 페이징 처리/ 검색 처리
	 */
	@GetMapping("/classList")
	public void list(Criteria cri, Model model, 
			@RequestParam(required = false, defaultValue = "title") String type,
			@RequestParam(required = false) String keyword) {
		model.addAttribute("list", service.getList(cri));
		int total = service.getTotalCount(cri);
		model.addAttribute("pageMaker", new PageDTO(cri, total));
		
		/* model.addAttribute("total", total); */
	}
	
	/*
	 * 작성자 : 고은진
	 * 기능 :  상세페이지
	 */
	@GetMapping("/classDetail")
	public void detail(Model model) {
		
	}
	
}
