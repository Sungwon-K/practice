package com.codingclass.security;

public class sample {

}
