package com.codingclass.domain;

import lombok.Data;

@Data
public class QnaReplyVO {
	
	private long qnaReplyNo;
	private String qnaReplycontent;
	private long qnaNo;
	private long userNo;
	

}
