package com.codingclass.domain;

import java.util.List;

import lombok.Data;


@Data
public class SessionVO {
	
	private long sessionNo;
	private String sessionTitle;
	
	private long classNo;
	
	//sessionNo로 연결된 studyVideo리스트
	private List<StudyVideoVO> studyVideoList;
	
}
