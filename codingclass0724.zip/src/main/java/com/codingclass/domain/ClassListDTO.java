package com.codingclass.domain;

import java.sql.Date;

import lombok.Data;

@Data
public class ClassListDTO {
	
	
	private String qnaTitle;
	private Date qnaDate;
	private String classTitle;
	private long classNo;
	
}
