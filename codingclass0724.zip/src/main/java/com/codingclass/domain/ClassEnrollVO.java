package com.codingclass.domain;

import lombok.Data;

@Data
public class ClassEnrollVO {
	
	private long userNo;
	private long classNo;
}
