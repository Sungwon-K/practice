package com.codingclass.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ClassUserListCriteria {
	private int pageNum;
	private int amount;
	
//	private String type;
	private String keyword;
	private long userno;
	private long classno;
	
	
	
	
	public ClassUserListCriteria() {
		
		this(1,5,"");
		
		
	}
	public ClassUserListCriteria(int pageNum , int amount, String keyword) {
		
		
		this.pageNum = pageNum;
		this.amount = amount;
		this.keyword = keyword;
		
	}
	public ClassUserListCriteria(int pageNum, int amount, String keyword, long userno) {
		this.pageNum = pageNum;
		this.amount = amount;
		this.keyword = keyword;
		this.userno = userno;
	}
	
	public ClassUserListCriteria(int pageNum, int amount, String keyword, long userno, long classno) {
		this.pageNum = pageNum;
		this.amount = amount;
		this.keyword = keyword;
		this.userno = userno;
		this.classno = classno;
	}

}