package com.codingclass.domain;

import java.util.Date;

import lombok.Data;

@Data
public class ReviewVO {
	private long reviewNo;
	private String reviewTitle;
	private String reviewComment;
	private Date date;
	private String reviewReply;
	private long reviewStar;
	private long classNo;
	
	/* 추가부분 */
	
}
