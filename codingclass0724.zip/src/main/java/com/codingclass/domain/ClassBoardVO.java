package com.codingclass.domain;

import java.util.Date;

import lombok.Data;

@Data
public class ClassBoardVO {
	
	private long boardNo;
	private String boardTitle;
	private String boardContent;
	private Date boardDate;
	private long classNo;
	

}
