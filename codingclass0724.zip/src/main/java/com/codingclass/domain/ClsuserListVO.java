package com.codingclass.domain;

import lombok.Data;

@Data
public class ClsuserListVO {
//c.classno, u.userno, u.userid, u.usernickname
	/*
	 *작성자 : 정찬화
	 *파일명 : ClsuserListVO
	 *기능 : 클래스 학습자 VO
	 */
	private Long classno;
	private Long userno;
	private String userid;
	private String usernickname;
}
