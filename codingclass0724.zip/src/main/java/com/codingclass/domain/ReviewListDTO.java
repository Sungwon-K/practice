package com.codingclass.domain;

import lombok.Data;

@Data
public class ReviewListDTO {
	
	private String reviewComment;
	private int reviewStar;
	private String classTitle;
	private String userNickName;
	
}
