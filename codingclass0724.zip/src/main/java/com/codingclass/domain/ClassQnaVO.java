package com.codingclass.domain;

import java.util.Date;

import lombok.Data;

@Data
public class ClassQnaVO {
	private long qnaNo;
	private String qnaTitle;
	private Date qnaDate;
	private String qnaContent;
	private long classNo;
	private long userNo;
	
	/* 추가부분 */
	
}
