package com.codingclass.domain;



import lombok.Getter;
import lombok.ToString;


@Getter
@ToString
public class ClsuserPageDTO {

	private int startPage;
	private int endPage;
	private boolean prev,next;
	
	private int total;
	private ClassUserListCriteria cri;
	
	public ClsuserPageDTO(ClassUserListCriteria cri, int total) {
		this.cri = cri;
		this.total = total;
		
		this.endPage = (int)(Math.ceil(cri.getPageNum()/10.0))*10; //각 페이징 부분 마다의 마지막 번호 ex  << 1 ... 10(이거) >>
		this.startPage = this.endPage-9;
		int realEnd = (int)(Math.ceil((total * 1.0)/cri.getAmount()));
		if(realEnd<this.endPage) {
			this.endPage = realEnd;
		}
		this.prev = this.startPage >1;
		this.next = this.endPage < realEnd;
	}
}
