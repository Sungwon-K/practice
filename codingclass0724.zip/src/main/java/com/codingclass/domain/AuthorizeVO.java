package com.codingclass.domain;

import lombok.Data;

@Data
public class AuthorizeVO {
	
	private String userAuth;
	private long userNo;	
}
