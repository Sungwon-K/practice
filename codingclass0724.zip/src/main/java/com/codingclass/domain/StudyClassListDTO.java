package com.codingclass.domain;

import java.util.Date;

import lombok.Data;

@Data
public class StudyClassListDTO {
	
	private long userNo;	
	private long classNo;	
	private String classTitle;
	private String classFlag;
	
	private long studentCount;
	
	private Date classDate;
	private Date studyDate;
	
	
}
