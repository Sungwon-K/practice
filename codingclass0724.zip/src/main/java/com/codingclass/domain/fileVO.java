package com.codingclass.domain;

import lombok.Data;

@Data
public class fileVO {
	
	private String fileName;
	private String uuid;
	private String uploadPath;
	private long studyVideoNo;

}
