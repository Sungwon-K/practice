package com.codingclass.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.codingclass.domain.ClassListDTO;
import com.codingclass.domain.ClassVO;
import com.codingclass.domain.Criteria;
import com.codingclass.domain.ReviewListDTO;

public interface ClassMapper {

	/* classList목록  */
	public List<ClassVO> getList();
	
	/* class qna 목록  */
	public List<ClassListDTO> getClassQnaList();
	
	/* class 수강평 목록  */
	public List<ReviewListDTO> getClassReviewList();
	
	/* classlist.jsp 전체 목록 수 */
	public int getTotalCount(Criteria cri);
	
	/* classlist.jsp 페이징 */
	public List<ClassVO> getListWithPaging(Criteria cri);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getClassListWithPaging
	 *기능 :  강사관리 페이지 클래스 리스트 검색
	 */
	public List<ClassVO> getClassListWithPaging(@Param("cri") Criteria cri,@Param("userNo") Long userNo);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : classInsert
	 *기능 : 클래스 테이블에 정보입력
	 */
	public void classInsert(ClassVO classes);
	
	 
	/*
	 * 작성자 : 김성원 
	 * 메소드명 : classUpdate
	 * 기능 : 클래스 테이블에 정보수정
	 */
	public void classUpdate(ClassVO classes);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : studyClassRead
	 *기능 : 클래스 리스트 한건 검색
	 */
	public ClassVO studyClassRead(Long classNo);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : getClassTotalCount
	 *기능 : 강사관리 페이지 전체 글 수 검색
	 */
	public int getClassTotalCount(Criteria cri);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : deleteCall
	 *기능 : 어드민에게 삭제 요청
	 */
	public int deleteCall(Long classNo);
	
	/*
	 *작성자 : 김성원
	 *메소드명 : deleteCallCancel
	 *기능 : 어드민에게 삭제 요청
	 */
	public int deleteCallCancel(Long classNo);

}
