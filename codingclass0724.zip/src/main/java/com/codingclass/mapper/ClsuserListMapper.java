package com.codingclass.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.codingclass.domain.ClassUserListCriteria;
import com.codingclass.domain.ClsuserListVO;

public interface ClsuserListMapper {

	
	/*
	 *작성자 : 정찬화
	 *메소드명 : getListpaging
	 *기능 : 클래스 학습자 전체 뽑아냄
	 */
	public List<ClsuserListVO> getListWithPaging(@Param("cri") ClassUserListCriteria cri,@Param("userNo") Long userNo);
	/*
	 *작성자 : 정찬화
	 *메소드명 : getListWithPagingPerClass
	 *기능 : 클래스 별 학습자 전체 뽑아냄 
	 */
	public List<ClsuserListVO> getListWithPagingPerClass(@Param("cri") ClassUserListCriteria cri,@Param("classNo") Long classNo);
	
	/*
	 *작성자 : 정찬화
	 *메소드명 : searchCnt
	 *기능 : 사용자 id 검색
	 */
	public int searchCnt(@Param("cri") ClassUserListCriteria cri,@Param("userNo") Long userNo);
	
	public int searchCntPerClass(@Param("cri") ClassUserListCriteria cri,@Param("classNo") Long classNo);
}
