package com.codingclass.mapper;

import java.util.List;

import com.codingclass.domain.StudyVideoVO;

public interface StudyVideoMapper {

	public void studyVideoInsert(StudyVideoVO vo);

	public void studyVideoUpdate(StudyVideoVO vo);

	public void delete(Long studyVideoNo);
	
	public List<StudyVideoVO> findBySessionNo(Long sessionNo);
}
