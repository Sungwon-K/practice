package com.codingclass.mapper;

import java.util.List;

import com.codingclass.domain.SessionVO;

public interface SessionMapper {
	
	public void sessionInsert(SessionVO vo);
	
	public void sessionUpdate(SessionVO vo);
	
	public List<SessionVO> findByClassNo(Long classNo);
	
}
